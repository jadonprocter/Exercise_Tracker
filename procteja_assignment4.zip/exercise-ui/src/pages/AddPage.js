import { useState } from "react";
import { Link, useHistory } from "react-router-dom";
import Incementor from "../components/Incrementor";

function AddPage() {
  const [name, setName] = useState("");
  const [reps, setReps] = useState(0);
  const [weight, setWeight] = useState(0);
  const [unit, setUnit] = useState("kgs");
  const [date, setDate] = useState("00-00-00");

  const history = useHistory();

  const addExercise = (event) => {
    console.log(event);
    event.preventDefault();
    const newExercise = JSON.stringify({ name, reps, weight, unit, date });
    console.log(newExercise);

    fetch("/exercise", {
      method: "POST",
      body: newExercise,
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => console.log(res))
      .catch((err) => {
        console.error({ error: err });
      });

    history.push("/");
  };

  return (
    <div>
      <h1>AddPage</h1>
      <form>
        <table className="other-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Reps</th>
              <th>Weight</th>
              <th>Unit</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <input
                  name="name"
                  type="text"
                  placeholder="Exercise"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                />
              </td>
              <td>
                <Incementor value={reps} setValue={setReps} />
              </td>
              <td>
                <Incementor value={weight} setValue={setWeight} />
              </td>
              <td>
                <select
                  name="unit"
                  value={unit}
                  onChange={(e) => {
                    setUnit(e.target.value);
                  }}
                >
                  <option value="kgs">kgs</option>
                  <option value="lbs">lbs</option>
                </select>
              </td>
              <td>
                <input
                  type="text"
                  placeholder="MM-DD-YY"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                  }}
                />
              </td>
            </tr>
          </tbody>
        </table>
        <button onClick={addExercise}>ADD</button>
      </form>
    </div>
  );
}

export default AddPage;
