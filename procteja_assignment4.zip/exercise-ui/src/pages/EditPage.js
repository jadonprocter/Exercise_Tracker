import { useHistory } from "react-router";
import { useState } from "react";
import Incementor from "../components/Incrementor";

function EditPage({ exerciseToEdit }) {
  const [name, setName] = useState(exerciseToEdit.name);
  const [reps, setReps] = useState(exerciseToEdit.reps);
  const [weight, setWeight] = useState(exerciseToEdit.weight);
  const [unit, setUnit] = useState(exerciseToEdit.unit);
  const [date, setDate] = useState(exerciseToEdit.date);

  const history = useHistory();

  const editExercise = (event) => {
    console.log(event);
    event.preventDefault();
    const editedExercise = JSON.stringify({ name, reps, weight, unit, date });
    console.log(editedExercise);

    fetch(`/exercise/${exerciseToEdit._id}`, {
      method: "PUT",
      body: editedExercise,
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => console.log(res))
      .catch((err) => {
        console.error({ error: err });
      });

    history.push("/");
  };

  return (
    <div>
      <h1>EditPage</h1>
      <form>
        <table className="other-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Reps</th>
              <th>Weight</th>
              <th>Unit</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <input
                  name="name"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                />
              </td>
              <td>
                <Incementor value={reps} setValue={setReps} />
              </td>
              <td>
                <Incementor value={weight} setValue={setWeight} />
              </td>
              <td>
                <select
                  name="unit"
                  value={unit}
                  onChange={(e) => {
                    setUnit(e.target.value);
                  }}
                >
                  <option value="kgs">kgs</option>
                  <option value="lbs">lbs</option>
                </select>
              </td>
              <td>
                <input
                  type="text"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                  }}
                />
              </td>
            </tr>
          </tbody>
        </table>
        <button onClick={editExercise}>EDIT</button>
      </form>
    </div>
  );
}

export default EditPage;
