import { useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import ExerciseTable from "../components/ExerciseTable";

function HomePage({ setExerciseToEdit }) {
  const [exercises, setExercises] = useState([]);
  const history = useHistory();

  const getExercises = async () => {
    const response = await fetch("/exercise");
    const data = await response.json();
    setExercises(data);
  };

  const deleteExercise = async (_id) => {
    const response = await fetch(`/exercise/${_id}`, { method: "DELETE" });
    if (response.status === 204) {
      const newExercises = exercises.filter((exercise) => exercise._id !== _id);
      setExercises(newExercises);
    } else {
      console.error("Failed to Delete");
    }
  };

  const editExercise = async (exercise) => {
    setExerciseToEdit(exercise);
    history.push("/edit");
  };

  useEffect(() => {
    getExercises();
  }, []);

  return (
    <div>
      <h1>HOMEPAGE</h1>
      <ExerciseTable
        exercises={exercises}
        deleteExercise={deleteExercise}
        editExercise={editExercise}
      />
      <Link to="/add">Add Page</Link>
    </div>
  );
}

export default HomePage;
