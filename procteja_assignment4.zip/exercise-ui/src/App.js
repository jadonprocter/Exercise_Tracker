import { BrowserRouter as Router, Route } from "react-router-dom";
import "./App.css";
import AddPage from "./pages/AddPage";
import EditPage from "./pages/EditPage";
import HomePage from "./pages/HomePage";
import { useState } from "react";

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();
  return (
    <div className="App">
      <header className="App-header">
        <Router>
          <Route path="/" exact>
            <HomePage setExerciseToEdit={setExerciseToEdit} />
          </Route>
          <Route path="/edit">
            <EditPage exerciseToEdit={exerciseToEdit} />
          </Route>
          <Route path="/add">
            <AddPage />
          </Route>
        </Router>
      </header>
    </div>
  );
}

export default App;
