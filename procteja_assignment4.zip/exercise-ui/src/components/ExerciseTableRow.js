import { MdDeleteForever } from "react-icons/md";
import { AiOutlineEdit } from "react-icons/ai";

function ExerciseTableRow({ exercise, deleteExercise, editExercise }) {
  return (
    <tr>
      <td>{exercise.name}</td>
      <td>{exercise.reps}</td>
      <td>{exercise.weight}</td>
      <td>{exercise.unit}</td>
      <td>{exercise.date}</td>
      <td>
        <AiOutlineEdit onClick={() => editExercise(exercise)} />
      </td>
      <td>
        <MdDeleteForever onClick={() => deleteExercise(exercise._id)} />
      </td>
    </tr>
  );
}

export default ExerciseTableRow;
