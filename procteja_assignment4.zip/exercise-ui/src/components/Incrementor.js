import { BiPlusCircle, BiMinusCircle } from "react-icons/bi";

function Incementor({ value, setValue }) {
  const increment = () => setValue(value + 1);
  const deincrement = () =>
    value - 1 >= 0 ? setValue(value - 1) : setValue(value);

  return (
    <span>
      <BiMinusCircle onClick={deincrement} />
      {value}
      <BiPlusCircle onClick={increment} />
    </span>
  );
}

export default Incementor;
