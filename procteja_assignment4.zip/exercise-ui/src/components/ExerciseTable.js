import ExerciseTableRow from "./ExerciseTableRow";

function ExerciseTable({ exercises, deleteExercise, editExercise }) {
  return (
    <div>
      <table className="exercise-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Reps</th>
            <th>Weight</th>
            <th>Unit</th>
            <th>Date</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {exercises.map((exercise, i) => {
            return (
              <ExerciseTableRow
                exercise={exercise}
                key={i}
                editExercise={editExercise}
                deleteExercise={deleteExercise}
              />
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default ExerciseTable;
